'use client';
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Rocket, PhoneCall } from "lucide-react";

export default function Landing() {
  return (
    <section className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-gray-900 to-gray-800 text-white px-6 py-12">
      <motion.h1
        className="text-4xl md:text-6xl font-bold text-center mb-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        Ready to Accelerate Your Career in Automotive Marketing?
      </motion.h1>
      <motion.p
        className="text-lg md:text-2xl text-center max-w-3xl mb-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        AutoPro EDGE is your ignition key to transformation. A coaching platform built exclusively for automotive marketing professionals.
      </motion.p>
      <div className="flex flex-col md:flex-row gap-4">
        <Button
          size="lg"
          className="bg-blue-600 hover:bg-blue-700 text-lg px-6 py-4 rounded-xl shadow-lg flex items-center gap-2"
          onClick={() => window.open(process.env.NEXT_PUBLIC_CALENDLY_LINK, "_blank")}
        >
          <Rocket className="w-5 h-5" /> Book Your Free Strategy Call
        </Button>
        <Button
          size="lg"
          variant="outline"
          className="border-green-500 text-green-500 hover:bg-green-600 hover:text-white text-lg px-6 py-4 rounded-xl shadow-lg flex items-center gap-2"
          onClick={() => window.open(process.env.NEXT_PUBLIC_WHATSAPP_LINK, "_blank")}
        >
          <PhoneCall className="w-5 h-5" /> Chat on WhatsApp
        </Button>
      </div>
    </section>
  );
}
